let soma = 0
let anterior = 0
let proximo = 1

document.write ('<img src="fibo.jpg" alt="">')

for (i=0; i<=10; i++){
    soma = anterior + proximo
    anterior = proximo
    proximo = soma
    
    document.write(soma + ' ')
    document.write('<br>')
}