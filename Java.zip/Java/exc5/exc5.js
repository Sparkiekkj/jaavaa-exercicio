let valor = parseInt(prompt('Digite um número inteiro:'))
let valor2 =  parseInt(prompt('E agora um número que vai ser o potencial:'))

alert(Math.sqrt(valor))
alert(Math.cbrt(valor))
alert(Math.pow(valor, valor2))