let soma = 0
for(i = 0; i <= 1000; i++){
    soma = i + i

    document.write(mult + ' ')
}